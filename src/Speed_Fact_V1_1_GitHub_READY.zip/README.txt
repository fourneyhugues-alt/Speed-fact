SPEED FACT V1.1.0 — 30/08/2026

Nouveautés V1.1
- Plusieurs entreprises émettrices, avec entreprise par défaut et choix au moment de facturer.
- Fiches entreprises complètes : raison sociale, adresse, SIRET, TVA, téléphone, mail, IBAN, BIC, banque, conditions de règlement, agrément phyto.
- Fiches clients complètes : coordonnées, SIRET, TVA, téléphone, e-mails, exploitations et parcelles.
- Création automatique d'une fiche client minimale lors d'un chantier si le client n'existe pas.
- Un client peut regrouper plusieurs exploitations ; une facture peut regrouper tous ses chantiers sélectionnés.
- TVA par chantier / ligne de facture, avec récapitulatif par taux.
- Modification et suppression des chantiers non facturés.
- Historique des factures avec copie figée des coordonnées client et entreprise de l'époque.
- Facture A4 portrait + toutes les fiches travaux en annexes dans le même document imprimable/PDF.
- Logo MEA/bourdon conservé sur les documents, quelle que soit l'entreprise émettrice.
- E-mail client repris automatiquement depuis sa fiche.
- Catalogue E-Phy conservé séparément.
- Mécanisme de mise à jour PWA passé en 1.1.0.

IMPORTANT SUR L'ENVOI MAIL
La V1.1 prépare automatiquement le destinataire, l'objet et le message à partir de la fiche client. Le PDF complet est toujours facture + fiches travaux. Comme l'application actuelle est une PWA statique, le navigateur ne peut pas envoyer lui-même une pièce jointe PDF sans service d'envoi côté serveur. Pour l'instant : PDF / Imprimer, puis ENVOYER ouvre le mail prérempli. Une future connexion à un service mail permettra l'envoi réellement automatique.

MISE EN LIGNE
Remplacer les fichiers du dépôt GitHub Speed-fact par ceux de cette archive en conservant exactement les dossiers src/ et assets/. Cloudflare redéploiera ensuite le dépôt.
